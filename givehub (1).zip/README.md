# Quick start: npm install && cp .env.example .env && edit .env && npm run db:push && npm run seed && npm run dev
